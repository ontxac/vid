uSnip=['#!', '"^#', 'ifmain', 'with', 'for', 'class', 'slotclass', 'contain', 'context', 'attr', 'desc', 'cmp', 'repr', 'numeric', 'deff', 'def', 'defc', 'defs', '/(^|(?<=\\W))\\./', 'from', 'roprop', 'rwprop', 'if', 'ife', 'ifee', 'try', 'trye', 'tryf', 'tryef', 'ae', 'at', 'af', 'aae', 'ar', 'an', 'ann', 'testcase', '"', "'", 'doc', 'pmdoc']
print(uSnip)
