import vim
import os
#print(vim.api.__dir__())

class Finder:
    def find(self) -> None:
        if not self.is_filetype_supported():
            print('filetype not supported')
            return
        file_name = vim.eval("expand('%:t:r')")
        project_directory = vim.eval("finddir('.git/..', expand('%:p:h').';')")
        test_file_path = ''
        for root, dir, files in os.walk(project_directory):
            for name in files:
                if name == file_name+"Test.php":
                    test_file_path = os.path.join(root, name)
                    vim.command(":vs %s" % test_file_path)
                    break
        if test_file_path == '':
            print('No test was found for the current file')

    def is_filetype_supported(self) -> bool:
        if(vim.eval("&filetype") != 'php'):
            return False
        return True
#['_session', 'channel_id', 'metadata', 'version', 'types', 'api', 'vars', 'vvars', 'options', 'buffers', 'windows', 'tabpages', 'current', 'session', 'funcs', 'lua', 'error', '_decode', '_err_cb', 'loop', '__module__', 'eval', '__doc__', 'from_session', 'from_nvim', '__init__', '_from_nvim', '_to_nvim', '_get_lua_private', 'request', 'next_message', 'run_loop', 'stop_loop', 'close', '__enter__', '__exit__', 'with_decode', 'ui_attach', 'ui_detach', 'ui_try_resize', 'subscribe', 'unsubscribe', 'command', 'command_output', 'call', 'exec_lua', 'strwidth', 'list_runtime_paths', 'foreach_rtp', 'chdir', 'feedkeys', 'input', 'replace_termcodes', 'out_write', 'err_write', '_thread_invalid', 'quit', 'new_highlight_source', 'async_call', '__dict__', '__weakref__', '__new__', '__repr__', '__hash__', '__str__', '__getattribute__', '__setattr__', '__delattr__', '__lt__', '__le__', '__eq__', '__ne__', '__gt__', '__ge__', '__reduce_ex__', '__reduce__', '__getstate__', '__subclasshook__', '__init_subclass__', '__format__', '__sizeof__', '__dir__', '__class__']
