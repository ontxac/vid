from math import floor
def zoomIncrease(*args):
    orgBufsize=vim.api.win_get_width(0)
    orgBufsize=floor(orgBufsize*2)
    vim.api.win_set_width(0, orgBufsize)

def zoomReduce(*args):
    orgBufsize=vim.api.win_get_width(0)
    orgBufsize=floor(orgBufsize/2)
    vim.api.win_set_width(0, orgBufsize)

zoomed=False
def zoomToggle():
    global zoomed
    orgBufsize=vim.api.win_get_width(0)
    orgBufsize=2*orgBufsize if zoomed else floor(orgBufsize/2.)
    zoomed=not zoomed
    vim.api.win_set_width(0, orgBufsize)

vim.api.set_keymap('n', '<leader>zm', '<cmd>py3 zoomToggle()<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>czm', '<cmd>py3 zoomIncrease("f-args")<CR>', {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>rzm', '<cmd>py3 zoomReduce("f-args")<CR>', {'noremap':True, 'silent':False})
