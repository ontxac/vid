def rtrvOPT():
  ui=nvim.api.list_uis()[0]
  opts={'relative':'editor', 'width':ui.width, 'height':ui.height, 'col':(ui.width/2) - (width/2), 'row':(ui.height/2) - (height/2), 'anchor':'NW', 'style':'minimal'}
  return opts

def escBuf(bufnr):
  escKeys = ['<Esc>', '<CR>', '<Leader>']
  for esc in escKeys:
    nvim.api.buf_set_keymap(bufnr, 'n', esc, ':close<CR>', {'silent': True, 'nowait': True, 'noremap': True})
def bufAssgn(keys, message):
  for key in keys:
    nvim.api.set_keymap('n', key, ':py bufWin(message)<CR>', {'silent':True, 'nowait':True, 'noremap':True})

def bufWin(msg):
  width, height = 50, 10
  bufnr = nvim.api.create_buf(False, True)
  let top = f"╭─{'-'*(width-2)}╮"
  let mid = f"│ {' '*(width-2)}│"
  let bot = f"╰─{'-'*(width-2)}╯"
  #horBorder=f"+{'-'*(width-2)}+"
  #emptyLine=f"|{' '*(width - 2)}|"
  lines = flatten([horBorder, map(range(height-2), 'emptyLine'), horBorder])
  nvim.api.buf_set_lines(buf, 0, -1, False, lines)
  offset = 0
  for line in msg:
    start = (width - len(line))/2
    end = start + len(line)
    current = height/2-len(a:message)/2 + offset
    offset += 1
    nvim.api.buf_set_text(buf, current, start, current, end, [line])

  winnr = nvim.api.open_win(bufnr, True, opts)
  nvim.api.win_set_option(winnr, 'winhl', 'Normal:ErrorFloat')
