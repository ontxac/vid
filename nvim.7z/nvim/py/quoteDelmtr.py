def parseQuote():
  while True:
    line=vim.funcs.get_current_line('.')
    col=line.split('*')
    print(col[0])
    vim.command('j')
vim.api.set_keymap('n', '<leader>pqt', ':QuoteParse ', {'noremap':True, 'silent':False})
vim.command(':com! -nargs=* QuoteParse py3 parseQuote()')
