vim.api.set_keymap('n', '<leader>pqi', "<cmd>PaqInstall<CR>", {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>pqu', "<cmd>PaqUpdate<CR>", {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>pqc', "<cmd>PaqClean<CR>", {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>pqs', "<cmd>PaqSync<CR>", {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>pqt', "<cmd>PaqList<CR>", {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>pqo', "<cmd>PaqLogOpen<CR>", {'noremap':True, 'silent':False})
vim.api.set_keymap('n', '<leader>pln', "<cmd>PaqLogClean<CR>", {'noremap':True, 'silent':False})

