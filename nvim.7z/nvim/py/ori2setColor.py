colors = {}

vim.api.set_option('termguicolors', True)
lightviolet={'gui':'lightviolet', 'cterm':'lightviolet'} #16 #0c1014
lightcyan={'gui':'lightcyan', 'cterm':'lightcyan'}#233 #11151c
LightGreen=lightgreen={ 'gui':'lightgreen', 'cterm':'lightgreen'}#17 #091f2e
lightorange={'gui':'lightorange', 'cterm':'lightorange'} #18 #0a3749
lightblue={'gui':'lightblue', 'cterm':'lightblue'}#31 #1e6479
lightpurple={'gui':'lightpurple', 'cterm':'lightpurple'} #81 #599cab
lightyellow={'gui':'lightyellow', 'cterm':'lightyellow'}#122#99d1ce
Yellow={'gui':'Yellow', 'cterm':'Yellow'}#122#99d1ce
lightred={'gui':'lightred', 'cterm':'lightred'}#194 #d3ebe9
White= { 'gui': 'White', 'cterm':'White' } ##ff0000 #d3ebe9

purple={'gui':'purple', 'cterm':'purple'} #81 #599cab
red = { 'gui': 'red', 'cterm':'red' } ##c23127 196
orange = { 'gui': 'Orange', 'cterm':'orange' } ##d26937 166
yellow = { 'gui': 'yellow', 'cterm':'yellow' } ##edb443 226
magenta = { 'gui': 'magenta', 'cterm':'magenta' } #888ca6 90
violet = { 'gui': 'violet', 'cterm':'violet' } #4e5166 60
blue = { 'gui': 'blue', 'cterm':'blue' } #195466 24
cyan = { 'gui': 'cyan', 'cterm':'cyan' } #33859E 44
Green = green = { 'gui': 'green', 'cterm':'green' } #2aa889 46
white = { 'gui': 'white', 'cterm':'White' } #2aa889 46
Magenta = { 'gui': 'Magenta', 'cterm':'Magenta' } #2aa889 46

#hi debugPC term=reverse ctermbg=lightblue guibg=lightblue
#hi debugBreakpoint term=reverse ctermbg=red guibg=red
#hi debugPC term=reverse ctermbg=darkblue guibg=darkblue
#hi debugBreakpoint term=reverse ctermbg=red guibg=red
"""
termColor8 = termColor0 = base0.get('gui')
termColor9 = termColor1 = red.get('gui')
termColor10 = termColor2 = green.get('gui')
termColor11 = termColor3 = yellow.get('gui')
termColor12 = termColor4 = blue.get('gui')
termColor13 = termColor5 = violet.get('gui')
termColor14 = termColor6 = cyan.get('gui')
termColor15 = termColor7 = base6.get('gui')

bckGrnd = base0
lnrBckgrnd = base1

"""

def hiSET(hiTerm, guifg, guibg, isBold=None):
 #print('Color=', ctermfg, ctermbg)
 """
 if ctermbg and ctermbg!='None':
 # ctrmbg=ctermbg.get('cterm', None) if ctermbg else None
 guibg=ctermbg.get('gui', None)
 else:
 guibg=None #ctermbg.get('gui', )
 #if ctermfg and ctermfg!='None':
 # ctrmfg=ctermfg.get('cterm', None) if ctermfg else None
 guifg=ctermfg.get('gui', None)
 """

 #CMD=f'exec "hi clear {hiTerm}|hi {hiTerm} ctermfg={ctermfg} ctermbg={ctermbg} guifg={ctermfg} guibg={ctermbg} gui=NONE cterm=NONE"'
 #set termguicolors
 #if ctermbg:
 CMD=f'exec "hi clear {hiTerm}|hi! {hiTerm} guifg={guifg} guibg={guibg}"' #ctermfg={ctrmfg} ctermbg={ctrmbg}
 if isBold:
   #boldTerm=''
   CMD=f'exec "hi clear {hiTerm}|hi! {hiTerm} guifg={guifg} guibg={guibg} gui=bold"' #ctermfg={ctrmfg} ctermbg={ctrmbg} 
 #print('CMD=', CMD)
 vim.command(CMD)

"""
Red LightRed DarkRed Green LightGreen DarkGreen SeaGreen Blue LightBlue DarkBlue SlateBlue Cyan LightCyan DarkCyan Magenta LightMagenta DarkMagenta Yellow LightYellow Brown DarkYellow Gray LightGray DarkGray Black White Orange Purple Violet
Red LightRed DarkRed Green LightGreen DarkGreen SeaGreen Blue LightBlue DarkBlue SlateBlue Cyan LightCyan DarkCyan Magenta LightMagenta DarkMagenta Yellow LightYellow Brown DarkYellow Gray LightGray DarkGray Black White Orange Purple Violet
The format is "#rrggbb", where "rr" is the Red value "gg" is the Green value "bb" is the Blue value. All values are hexadecimal, range from "00" to "ff".  :highlight Comment guifg=#11f0c3 guibg=#ff00ff
"""
hiSET('Normal', 'LightPurple', None)
hiSET('Cursor', 'Cyan', None)
hiSET('Search', 'red', None, isBold=True)
hiSET('CursorLine', 'magenta', None)
#hiSET('CursorColumn', 'magenta', base1)
#hiSET('LineNr', 'yellow', 'lnrBckgrnd')
#hiSET('CursorLineNr', 'base5', 'lnrBckgrnd')
#hiSET('SignColumn', None, 'lnrBckgrnd')
#hiSET('ColorColumn', None, 'lnrBckgrnd')
#hiSET('Conceal', 'cyan', 'bckGrnd')
#hiSET('Todo', 'magenta', 'bckGrnd')

hiSET('pythonComment', 'White', None)
hiSET('pythonStatement', 'lightgreen', None)
hiSET('pythonFunction', 'lightred', None)
hiSET('pythonString', 'Yellow', None)
hiSET('String', 'green', None)
hiSET('Number', 'orange', None)
hiSET('Comment', 'cyan', None)
hiSET('Statement', 'lightgreen', None)
#hiSET('Special', orange, None)
#hiSET('Identifier', base5, None)
#hiSET('Constant', magenta, None)

hiSET('VertSplit', 'red', 'LightGreen')
hiSET('StatusLine', 'lightred', None, isBold=True)
hiSET('WildMenu', 'lightpurple', 'cyan')
#hiSET('StatusLineNC', blue, base2)
#hiSET('ErrorMsg', cyan, base1)
#hiSET('Error', red, base1)
#hiSET('ModeMsg', blue, None)
hiSET('WarningMsg', 'red', None)

hiSET('TabLineSel', 'yellow', None, isBold=True)
hiSET('TabLine', 'red', None)
hiSET('TabLineFill', 'green', None)
#hiSET('Title', orange, yellow)

hiSET('Visual', 'yellow', 'magenta', isBold=True)
hiSET('CurSearch', 'cyan', None, isBold=True)
hiSET('MatchParen', 'lightorange', 'orange')
#call s:Attr('IncSearch', 'reverse')
#hiSET('Pmenu', base6, base2)
#hiSET('PmenuSel', base7, blue)
#hiSET('PmenuSbar', None, base2)
#hiSET('PmenuThumb', None, blue)
#hiSET('CtrlPNoEntries', base7, orange)
#hiSET('CtrlPMatch', green, orange)
#hiSET('CtrlPPrtBase', blue, orange)
#hiSET('CtrlPPrtText', cyan, orange)
#hiSET('CtrlPPtrCursor', base7, orange)
hiSET('pythonStatement', 'lightblue', None)

vim.command(':com! -nargs=* SetHiColor py3 hiSET(<f-args>)')
vim.api.set_keymap('n', '<leader>his', '<cmd>SetHiColor<CR>', {'noremap':True, 'silent':False})
#vim.api.set_hl(0, "Visual", {'fg':"yellow", 'bg':"Violet", 'bold':True})
