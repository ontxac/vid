from sys import path as sysPath
absPath=vim.funcs.expand('%:p:h')
sysPath.append(absPath)
from regMark import bufWin
spwnRslt=None
def onEvent(spawnrlst):
    spwnRslt=spawnrlst
    return spwnRslt
def spawnJob(*args):
    #CMD='ls *.py'
    CMD=' '.join(args)
    spawnRslt=vim.funcs.chansend(CMD, {'on_stdout': onEvent  })
    print('spwnRslt=', spwnRslt)
    bufWin(spwnRslt)
vim.command(':com! -nargs=* SpawnJob py3 spawnJob(<f-args>)')
vim.api.set_keymap('n', '<leader>sjb', ':SpawnJob ', {'noremap':True, 'silent':False})
