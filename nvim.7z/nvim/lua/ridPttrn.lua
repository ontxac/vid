local Rslt={}
local blnkPttrn, VisualModes='\\d\\d:\\d\\d\\_s', {'v', 'V', "\\<C-V>"}
local cptlPunct={'，', '。', '；', '．', '　', '「', '」'}
local cword, crrntRaw, mtchPttrn, prvPos
local vmLn, vmGtln, vmStln=vim.fn.line, vim.fn.getline, vim.fn.setline
local vmMtch, vmSbstt=vim.fn.match, vim.fn.substitute
local vmGtps, vmStps=vim.fn.getpos, vim.fn.setpos

RinseLine=function(crrntRaw, cword)
  --print('cword RinseLine',cword)
  --vim.fn.substitute(vim.fn.getline('.'), '\\.', '', 'g')
  --print('cword=', cword, cword:match('[\\u4E00-\\u9FFF]'))
  --print(vim.api.nvim_get_current_line():match('[^\\u4E00-\\u9FFF]..'))
  if crrntRaw == '' or vmMtch(crrntRaw, blnkPttrn .. '[\\u4E00-\\u9FFF]\\+\\_s[圖\\|影]片$') ~= -1 or vmMtch(crrntRaw, '^圖片$') ~= -1 or vmMtch(crrntRaw, '^\\_s*$') ~= -1 then
    vim.fn.deletebufline('', vim.fn.line('.'))
    crrntRaw=vmGtln('.')
    RinseLine(crrntRaw, cword)
  elseif vmMtch(crrntRaw, cword)==-1 then
    vim.cmd[[normal j]]
  else
    if vim.tbl_contains(cptlPunct, cword) then
      mtchPttrn='['.. table.concat(cptlPunct) ..']'
      crrntRaw=vmSbstt(crrntRaw, mtchPttrn, ' ', 'g')
    elseif vmMtch(crrntRaw, cword)~=-1 then
      --:lua print(crrntRaw:gsub('[%p%c%s]', ''))
      crrntRaw=crrntRaw:gsub(cword, ' ', 'g')--, vmSbstt()
      --crrntRaw=vmSbstt(crrntRaw, cword, ' ', 'g')
    else
      mtchPttrn=blnkPttrn .. cword .. '\\+\\_s'
      if vmMtch(crrntRaw, mtchPttrn)~=-1 then
        crrntRaw=vmSbstt(crrntRaw, mtchPttrn, '', 'g')
      end
    end
    vmStln('.', crrntRaw)
    vim.cmd[[normal j]]
  end
  if vmLn('$')==vmLn('.') then return end
end

local subStr, startPos, endPos, rplceBlnk
local vmCol, vmStrchrprt=vim.fn.col, vim.fn.strcharpart
local sbsttWord, nxtLnum, crrntLnum, mxmLnum, cnt, isPrcssd

Rslt.RidKeyword=function()
  --prvPos=vmGtps("'\"")
  prvPos=vim.fn.getpos("'\"")
  --crrntRaw=vmGtln('.')
  crrntRaw=vim.api.nvim_get_current_line()
  if vim.tbl_contains(VisualModes, vim.fn.visualmode(1)) then
    startPos, endPos=vmCol("'<"), vmCol("'>")+2
    --print('startPos', startPos, endPos)
    cword=string.sub(crrntRaw, startPos, endPos)
  else
    startPos=vmCol('.')
    --startPos=vim.api.nvim_win_get_cursor('.')
    --subStr=string.sub(crrntRaw, startPos)
    --_, startPos = vim.api.nvim_win_get_cursor(0)
    cword = string.sub(crrntRaw, startPos, startPos+2) -- Maybe col-1
    --print('cursor_char',cword)
    --cword=vmStrchrprt(subStr, 0, 1)
    if vim.tbl_contains(cptlPunct, cword) then
      cword='['.. table.concat(cptlPunct) ..']'
      --crrntRaw=vmSbstt(crrntRaw, mtchPttrn, ' ', 'g')
      rplceBlnk=true
    elseif string.match(cword, '%p') then  --vim.regex(cword, '[[:punct:]]')
      cword='%p%w%c'
      rplceBlnk=true
      --crrntRaw=crrntRaw:gsub('%p%w%c', ' ', 'g')--, vmSbstt()
    elseif string.match(cword, '%w') then
      cword=vim.fn.expand('<cword>')
      --crrntRaw=crrntRaw:gsub(cword, '', 'g')--, vmSbstt()
    end
  end
  --print('cword',cword)
  vim.cmd[[normal gg]]
  if rplceBlnk then sbsttWord=' ' else sbsttWord='' end
  --nxtLnum, curLnum='nextRaw', 'notTrue'vmLn('.')
  --crrntRaw=true
  crrntRaw=vim.api.nvim_get_current_line()
  cnt=0
  mxmLnum=vmLn('$')
  --while nextLnum~=vmLn('$') do
    --curLnum=vmLn('.')
  repeat
    --crrntLnum=vmLn('.')
    if crrntRaw == '' or vmMtch(crrntRaw, blnkPttrn .. '[\\u4E00-\\u9FFF]\\+\\_s[圖\\|影]片$') ~= -1 or vmMtch(crrntRaw, '^圖片$') ~= -1 or vmMtch(crrntRaw, '^\\_s*$') ~= -1 then
      vim.api.nvim_del_current_line()
      cnt=cnt+1
      --crrntRaw=vim.api.nvim_get_current_line()
    --else
    --  if isPrcssd then 
    --    vim.cmd[[normal j]] 
    --    isPrcssd=not isPrcssd
    --  end
    end
    crrntRaw=vim.api.nvim_get_current_line()
    crrntRaw=vmSbstt(crrntRaw, cword, sbsttWord, 'g')--, vmSbstt()
    vim.api.nvim_set_current_line(crrntRaw)
    nxtLnum=vmLn('.')+cnt
    --if not isPrcssd then
    --  vim.cmd[[normal j]]
    --  isPrcssd=true
    --else
    --  isPrcssd=nil
    --end
    --print('lastLine=', nxtLnum==mxmLnum)
    --if not isPrcssd then
    --  vim.cmd[[normal j]]
    --  isPrcssd=not isPrcssd
    --else isPrcssd=true
    --end
    --RinseLine(crrntRaw, cword)
  --while crrntRaw do
    --crrntRaw=vmGtln(curLnum)
    --RinseLine(crrntRaw, cword)
  until nxtLnum==mxmLnum
  vmStps(".", prvPos)
end

vim.api.nvim_set_keymap('n', '<leader>wc', "<cmd>lua require'ridPttrn'.RidKeyword()<CR>", {noremap=true, silent=true})

return Rslt
