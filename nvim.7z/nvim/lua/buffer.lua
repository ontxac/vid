--nnoremap <silent> <leader>bl :call SwitchToNextBuffer(1)<CR>
--nnoremap <silent> <leader>bh :call SwitchToNextBuffer(-1)<CR>
--nnoremap <silent> <leader>bp :bp!<CR>
--nnoremap <silent> <leader>bn :bn!<CR>
--nnoremap <silent> <leader>bx :bd<CR>
vim.api.nvim_set_keymap('n', '<leader>bp', '<cmd>bp!<CR>', {silent=false, noremap=true})
vim.api.nvim_set_keymap('n', '<leader>bn', '<cmd>bn!<CR>', {silent=false, noremap=true})
vim.api.nvim_set_keymap('n', '<leader>bx', '<cmd>bd<CR>', {silent=false, noremap=true})
