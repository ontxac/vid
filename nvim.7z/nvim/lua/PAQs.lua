--local snip=require'snip'
local paqTbl={
  --### img viewer ###
  --'adelarsq/image_preview.nvim';
  --'samodostal/image.nvim';
  'morhetz/gruvbox',
  'voldikss/vim-floaterm',
  'voldikss/vim-skylight',
  'nvim-lua/plenary.nvim',
  'nvim-lua/popup.nvim',
  'edluffy/hologram.nvim',
  --'ashisha/image.vim',
  'VonHeikemen/fine-cmdline.nvim',
  'dccsillag/magma-nvim',
  'MunifTanjim/nui.nvim',
  {"jackMort/ChatGPT.nvim",
  run = function()
    require'chatgpt'.setup({
      api_key_cmd = nil,
      yank_register = "+",
      edit_with_instructions = {
        diff = false,
        keymaps = { accept = "<C-y>", toggle_diff = "<C-d>", toggle_settings = "<C-o>", cycle_windows = "<Tab>", use_output_as_input = "<C-i>" },
      },
      chat = { welcome_message = WELCOME_MESSAGE, loading_text = "Loading, please wait ...", question_sign = "", answer_sign = "ﮧ", max_line_length = 120,
        sessions_window = {
          border = { text = { top = " Sessions " }, style = "rounded", },
          win_options = { winhighlight = "Normal:Normal,FloatBorder:FloatBorder" },
        },
        keymaps = { close = { "<C-c>" }, yank_last = "<C-y>", yank_last_code = "<C-k>", scroll_up = "<C-u>", scroll_down = "<C-d>", new_session = "<C-n>", cycle_windows = "<Tab>", cycle_modes = "<C-f>", select_session = "<Space>", rename_session = "r", delete_session = "d", draft_message = "<C-d>", toggle_settings = "<C-o>", toggle_message_role = "<C-r>", toggle_system_role_open = "<C-s>" },
      },
      popup_layout = {
        center = { width = "80%", height = "80%" },
        right = { width = "30%", width_settings_open = "50%" },
        default = "center",
      },
      popup_window = {
        border = {
          highlight = "FloatBorder",
          text = { top = " ChatGPT " },
          style = "rounded",
        },
        win_options = {
          wrap = true, linebreak = true, foldcolumn = "1", winhighlight = "Normal:Normal,FloatBorder:FloatBorder" },
        buf_options = { filetype = "markdown" },
      },
      system_window = {
        border = {
          highlight = "FloatBorder",
          text = { top = " SYSTEM " },
          style = "rounded",
        },
        win_options = { wrap = true, linebreak = true, foldcolumn = "2", winhighlight = "Normal:Normal,FloatBorder:FloatBorder" },
      },
      popup_input = {
        prompt = "  ",
        border = {
          highlight = "FloatBorder",
          text = { top_align = "center", top = " Prompt " },
          style = "rounded" },
        win_options = { winhighlight = "Normal:Normal,FloatBorder:FloatBorder", },
        submit = "<C-Enter>",
        submit_n = "<Enter>",
      },
      settings_window = {
        border = {
          text = { top = " Settings " },
          style = "rounded",
        },
        win_options = { winhighlight = "Normal:Normal,FloatBorder:FloatBorder" },
      },
      openai_params = { model = "gpt-3.5-turbo", frequency_penalty = 0, presence_penalty = 0, max_tokens = 300, temperature = 0, top_p = 1, n = 1 },
      openai_edit_params = {
        model = "code-davinci-edit-001", temperature = 0, top_p = 1, n = 1 },
      actions_paths = {},
      show_quickfixes_cmd = "Trouble quickfix",
      predefined_chat_gpt_prompts = "https://raw.githubusercontent.com/f/awesome-chatgpt-prompts/main/prompts.csv",
    })
  end},
  'sudormrfbin/cheatsheet.nvim',
  'nvim-telescope/telescope.nvim',
  'ggandor/leap.nvim',
  'nvim-lua/popup.nvim',
  --'nvim-lua/plenary.nvim',
  'smzm/hydrovim',
  --{  "folke/which-key.nvim",
  --  run = function()
  --    vim.o.timeout = true
  --    vim.o.timeoutlen = 300
  --    require("which-key").setup({
  --      -- your configuration comes here
  --      -- or leave it empty to use the default settings
  --      -- refer to the configuration section below
  --    })
  --    end
  --},
  --'sillybun/vim-repl',

  --#### jupyter  ####
  --'luk400/vim-jukit';
  --'ahmedkhalf/jupyter-nvim';
  --{'kiyoon/jupynium.nvim', run=function()vim.cmd[['pip3 install --user' ]]end };
	"jupyter-vim/jupyter-vim",
	--{'ahmedkhalf/jupyter-nvim', run=vim.cmd[[':UpdateRemotePlugins']] }, --
  --"ahmedkhalf/jupyter-nvim",
  --{'kiyoon/jupynium.nvim', run=function()vim.cmd[['pip3 install --user' ]]end };

    --'lucidrains/medical-chatgpt',

--- ### fexplorer  ###
  {"ms-jpq/chadtree", run=function()vim.cmd[[python -m chadtree deps]]end},  --branch='char', 
  --'nvim-tree/nvim-tree.lua';
  --Plug 'ms-jpq/chadtree', {'branch': 'chad', 'do': ''}

--###  cmp ###
	--"neovim/nvim-lspconfig",
	--{ "lervag/vimtex", opt = true }, -- Use braces when passing options
    { 'nvim-treesitter/nvim-treesitter', run = function() vim.cmd 'TSUpdate' end },
    'BurntSushi/ripgrep',
    'sharkdp/fd',
	--'hrsh7th/nvim-compe';
    'hrsh7th/nvim-cmp';
  --'nvim-lua/completion-nvim';
  --{'nvim-treesitter/nvim-treesitter', run = function() vim.cmd 'TSUpdate' end },
	'machakann/vim-sandwich',
	'windwp/nvim-autopairs',
  --{'windwp/nvim-ts-autotag', run=require('nvim-ts-autotag').setup()},
--'tpope/vim-surround';
	--'tpope/vim-surround';
--{ 'vim/better-text-objs', url='https://git.peppe.rs' };
--'kana/vim-textobj-user';
	--{ 'vim/better-text-objs', url='https://git.peppe.rs' };
	--'jiangmiao/auto-pairs';
--'jiangmiao/auto-pairs';
	-- 'airblade/vim-gitgutter';
	--{ 'vim/vim-colors-plain', url='https://git.peppe.rs' };
  --'neovim/nvim-lspconfig';
	-- 'nvim-lua/completion-nvim';
	-- 'steelsojka/completion-buffers';
	--'nvim-lua/popup.nvim';

--- ###   snip   ####
  --'norcalli/snippets.nvim';
  'SirVer/ultisnips';
  --'dcampos/nvim-snippy';
  --'L3MON4D3/LuaSnip'; --{, 'tag': 'v2.*', 'do': 'make install_jsregexp'};
  'Shougo/deoplete.nvim';
  --'honza/vim-snippets';
  --'norcalli/snippets.nvim';
  --'SirVer/ultisnips';

	"savq/paq-nvim";
	--'nvim-lua/plenary.nvim';
	-- 'wellle/targets.vim';
	-- 'tpope/vim-rsi';
}
--table.append(paqTbl, snip)
--for k, v in pairs(snip) do
--  table.insert(paqTbl, v)
--  --print(k, v)
--end
require "paq"( paqTbl)
-- require "paqKEY"
