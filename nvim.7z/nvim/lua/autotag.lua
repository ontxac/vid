require'nvim-treesitter.configs'.setup {
  autotag = { enable = true, }
}
local filetypes = { 'html', 'javascript', 'typescript', 'javascriptreact', 'typescriptreact', 'svelte', 'vue', 'tsx', 'jsx', 'rescript', 'xml', 'php', 'markdown', 'astro', 'glimmer', 'handlebars', 'hbs' }
local skip_tags = { 'area', 'base', 'br', 'col', 'command', 'embed', 'hr', 'img', 'slot', 'input', 'keygen', 'link', 'meta', 'param', 'source', 'track', 'wbr','menuitem' }
--require'nvim-treesitter.configs'.setup {
--  autotag = {
--    enable = true, enable_rename = true, enable_close = true, enable_close_on_slash = true, filetypes = { "html" , "xml" },
--  }
--}
-- OR
require('nvim-ts-autotag').setup({
  filetypes = { "html" , "xml" },
})

