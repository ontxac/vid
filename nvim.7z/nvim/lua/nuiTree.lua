local NuiTree = require("nui.tree")
local bufnr=vim.fn.bufnr()
local tree = NuiTree({
  bufnr = bufnr,
  nodes = {
    NuiTree.Node({ text = "a" }),
    NuiTree.Node({ text = "b" }, {
      NuiTree.Node({ text = "b-1" }),
      NuiTree.Node({ text = { "b-2", "b-3" } }),
    }),
  },
})

tree:render()
